# HR-Dashboard-Power-BI

[![Views](https://visitor-badge.glitch.me/badge?page_id=undiscovered-genius.undiscovered-genius/HR-Dashboard-Power-BI)](https://github.com/undiscovered-genius/HR-Dashboard-Power-BI)

<img src='Pics\1.jpg' class="center">
<img src='Pics\2.jpg' class="center">
<img src='Pics\3.jpg' class="center">
